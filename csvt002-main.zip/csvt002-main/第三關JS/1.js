var rightway="左";
var input;
prompt("回城堡的路是左邊嗎？還是右邊呢？")
if(input!=rightway)
{
    alert("在踏上錯誤道路的那一刻，勇者感到了一股來自東方的神祕力量，一陣暈眩感襲來，勇者發現他又回到了原點")
    location.href='1.html';
}
else
location.href='2.html';